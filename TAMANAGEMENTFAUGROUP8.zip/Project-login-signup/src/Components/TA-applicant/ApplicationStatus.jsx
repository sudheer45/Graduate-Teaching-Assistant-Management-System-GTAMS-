import React, { useEffect, useState } from "react";
import Navbar from "./Navbar";
import axios from "axios";

function ApplicationStatus() {
 
  const [data, setData] = useState({});
  const URL = "https://apitaassistant-app-2024102921080.nicecliff-6fd000a2.eastus2.azurecontainerapps.io/v1/Applications/statuses"
  const getApplicationStatus = async () => {
    try {
      const response = await axios.get(URL);
      console.log(response.data.data);
      setData(response.data.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(()=>{
    getApplicationStatus();

  },[])
  return (
    <>
      <div className="min-h-screen bg-gray-100 flex flex-col">
        <Navbar />
        <div className=" p-4">
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr>
                <th className="border border-gray-300 px-4 py-2">Subject</th>
                <th className="border border-gray-300 px-4 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {data.length > 0  && data.map((item, index) => (
                <tr key={index}>
                  <td className="border border-gray-300 px-4 py-2">
                    {item.applicationStatusId}
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    {item.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4">
            Back to Home
          </button>
        </div>
      </div>
    </>
  );
}

export default ApplicationStatus;
