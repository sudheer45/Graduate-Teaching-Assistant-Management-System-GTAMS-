import React, { useState } from "react";
import Navbar from "./Navbar";
import axios from "axios"
function ApplicationReview() {
  const URL = "https://apitaassistant-app-2024102921080.nicecliff-6fd000a2.eastus2.azurecontainerapps.io/";

  const [userId , setUserId] =useState({
    userId: "",
  }); 

  const [data , setData] = useState({});

  const HandleChange = (e) => {
    setUserId({userId, [e.target.name]:e.target.value});
  }
  const HandleGetUserData = async (e) =>{
    e.preventDefault();
    try {
      const response = await axios.get(`${URL}v1/Applications/users/${userId.userId}/upcoming`);
      console.log(response.data.data);
      setData(response.data.data);
    } catch (error) {
      console.log(error);
    }
  }
  return (
    <>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow bg-gray-100 flex flex-col items-center justify-start">
          <div className="text-gray-600 text-sm font-medium">
            <form onSubmit={HandleGetUserData}>
              {/* Email Input */}
              <div className="mb-4 border border-zinc-400 p-5 mt-2 rounded">
                <label className="text-gray-700" htmlFor="email">
                  Enter UserId:
                </label>
                <input
                  type="text"
                  id="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter Userid"
                  name="userId"
                  onChange={HandleChange}
                  required
                />

                <div className="mb-4">
                  <button
                    type="submit"
                    className="w-40 mt-3 bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition"
                  >
                    Check
                  </button>
                </div>
              </div>
            </form>
          </div>

          <table className="w-full border-collapse text-center">
          <thead>
            <tr>
              <th className="border border-gray-300 px-4 py-2 bg-gray-200">
                Application id
              </th>
              <th className="border border-gray-300 px-4 py-2 bg-gray-200">
                User id
              </th>
              <th className="border border-gray-300 px-4 py-2 bg-gray-200">
                Term Name
              </th>
              <th className="border border-gray-300 px-4 py-2 bg-gray-200">
                Application Status id
              </th>
              <th className="border border-gray-300 px-4 py-2 bg-gray-200">
                Year
              </th>
              <th className="border border-gray-300 px-4 py-2 bg-gray-200">
              status
              </th>
            </tr>
          </thead>
          <tbody>
            {data.length > 0  && data.map((data, index) => (
              <tr 
              key={index}
              >
                <td className="border border-gray-300 px-4 py-2">
                  {data.applicationId}
                </td>
                <td className="border border-gray-300 px-4 py-2">
                  {data.userId}
                </td>
                <td className="border border-gray-300 px-4 py-2">
                  <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                  >
                    {data.term.termName}
                  </button>
                </td>
                <td className="border border-gray-300 px-4 py-2">
                  {data.status.applicationStatusId}
                </td>
                <td className="border border-gray-300 px-4 py-2">
                 {data.year}
                </td>
                <td className="border border-gray-300 px-4 py-2">
                 {data.status.status}
                </td>
              </tr>
            ))} 
          </tbody>
        </table>
        </main>
      </div>
    </>
  );
}

export default ApplicationReview;
