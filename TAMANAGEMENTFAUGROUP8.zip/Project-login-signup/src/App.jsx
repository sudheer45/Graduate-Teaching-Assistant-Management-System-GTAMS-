import React from 'react';
import Routers from './Utils/Routers';

const App = () => {
  return (
   <>
    <Routers/>
   </>
  );
};

export default App;
